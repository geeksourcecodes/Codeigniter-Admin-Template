    <!-- .row -->
               <div class="row">
                  <div class="col-md-12">
                     <div class="white-box">
                       
					   
					   <div style="max-width: 700px; padding:50px 0;  margin: 0px auto; font-size: 14px">
    <table border="0" cellpadding="0" cellspacing="0" style="width: 100%; margin-bottom: 20px">
      <tbody>
        <tr>
          <td style="vertical-align: top; padding-bottom:30px;" align="center"><a href="http://optimumlinkupsoftware.com" target="_blank"><img src="<?php echo base_url(); ?>optimum/logo.png" alt="Codeigniter Admin Template" style="border:none"></a> </td>
        </tr>
      </tbody>
    </table>
    <div style="padding: 40px; background: #fff;">
      <table border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
        <tbody>
          <tr>
            <td><b>Dear Sir/Madam/Customer,</b>
              <p>This is to inform you that, Your account with Elite Admin has been created successfully. Log it for more details.</p>
              <a href="javascript: void(0);" style="display: inline-block; padding: 11px 30px; margin: 20px 0px 30px; font-size: 15px; color: #fff; background: #00c0c8; border-radius: 60px; text-decoration:none;"> Call to action button </a>
              <p>This email template can be used for Create Account, Change Password, Login Information and other informational things.</p>
              <b>- Thanks (Elite team)</b> </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div style="text-align: center; font-size: 12px; color: #b2b2b5; margin-top: 20px">
      <p> Powered by OptimumLinkupSoftware.com <br>
        <a href="javascript: void(0);" style="color: #b2b2b5; text-decoration: underline;">Unsubscribe</a> </p>
    </div>
  </div>
</div>

					   
					   
                     </div>
                  </div>
               </div>
               <!-- .row -->
			   
  
  